// Downloads HappyRobot Operations page assets to public/. Node 24+ (global fetch).
import { mkdir, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";

const BASE = "https://cdn.prod.website-files.com/686ce151be97e21fe2785a7e/";
const OUT = join(process.cwd(), "public");

// [remote filename (URL-encoded), local path under public/]
const ASSETS = [
  ["699d6fcaaa862b409f51e054_logo.svg", "images/happyrobot-logo.svg"],
  ["689a056579315b36a9832293_hero-bg%402x.webp", "images/hero-bg.webp"],
  ["6878803b9018d89e03ec3631_af926cea21857b2cfc256279bcd71e53_Frame%201597881333.webp", "images/powering-operations.webp"],
  ["698b69ce26973fe6bbde1ff3_8587db1f07421756d856241a4d10eeeb_Shared%20insight%20optimizes%20opportunity%20capture%27.webp", "images/contact-intelligence.webp"],
  ["698cc944500383768d124073_Vanta_Compliance_SOC%202.png", "images/compliance/soc2.png"],
  ["698cc9446dc5fdac1bd29e3b_Vanta_Compliance_GDPR.png", "images/compliance/gdpr.png"],
  ["698cc944e8723e399b34e77c_Vanta_Compliance_HIPAA.png", "images/compliance/hipaa.png"],
  ["698cc944328f4929f203b50c_Vanta_Compliance_EU%20AI%20Act_CSF.png", "images/compliance/eu-ai-act.png"],
  ["698cc944bdc405296ee58ee4_Vanta_Compliance_NIST%20CSF.png", "images/compliance/nist-csf.png"],
  ["698cc944d20f8dde09e1ab47_Vanta_Compliance_DORA.png", "images/compliance/dora.png"],
  ["699d6fca130f00818a8e1ee6_8594df2ae122696d461ffcda4605640f_logo-1.svg", "images/logos/logo-1.svg"],
  ["699d6fca7ea1276202a5c636_logo-2.svg", "images/logos/logo-2.svg"],
  ["699d6fca5f2aad2b6a81c516_logo-3.svg", "images/logos/logo-3.svg"],
  ["699d6fcaf9ac70ea93dd323b_8de3c2dbdb7970c5df2510b598d42a5e_logo-4.svg", "images/logos/logo-4.svg"],
  ["699d6fca1eb494275e901ae1_logo-5.svg", "images/logos/logo-5.svg"],
  ["699d6fca7d42ca77f0443292_logo-6.svg", "images/logos/logo-6.svg"],
  ["699d6fca1f86538f202eba85_logo-7.svg", "images/logos/logo-7.svg"],
  ["699d6fcae5dc110fcdfd1ac1_logo-8.svg", "images/logos/logo-8.svg"],
  ["699d6fcadedc977d56ccf5ff_logo-9.svg", "images/logos/logo-9.svg"],
];

async function dl([remote, local]) {
  const url = BASE + remote;
  const res = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0" } });
  if (!res.ok) throw new Error(`${res.status} ${url}`);
  const buf = Buffer.from(await res.arrayBuffer());
  const dest = join(OUT, local);
  await mkdir(dirname(dest), { recursive: true });
  await writeFile(dest, buf);
  return `${local} (${(buf.length / 1024).toFixed(1)} KB)`;
}

async function run() {
  const batch = 4;
  const ok = [], fail = [];
  for (let i = 0; i < ASSETS.length; i += batch) {
    const res = await Promise.allSettled(ASSETS.slice(i, i + batch).map(dl));
    res.forEach((r, j) => r.status === "fulfilled" ? ok.push(r.value) : fail.push(`${ASSETS[i + j][1]}: ${r.reason}`));
  }
  console.log("Downloaded:\n" + ok.map(s => "  " + s).join("\n"));
  if (fail.length) { console.error("FAILED:\n" + fail.map(s => "  " + s).join("\n")); process.exitCode = 1; }
}
run();
