# Page Topology — happyrobot.ai/solutions/functions/operations

Built with Webflow + Relume. Single scroll page, total height ~7714px @ 1536w.
Light theme only. Max content width ~1280px, centered, generous vertical padding.

## Fixed overlay
- **Navbar** — sticky top, bg `#FCFCFC`, ~64px tall. Left: HappyRobot logo (symbol + wordmark). Center: Product, Solutions, Customers, Blog, Careers. Right: black "Book a demo" button. Subtle peach glow line at very top of page only.

## Sections (top → bottom)
1. **Hero** (`section_header30`, ~745px) — full-bleed bridge photo bg (`hero-bg@2x.webp`, Golden Gate above clouds, blue→peach gradient). Centered: eyebrow "OPERATIONS" (white), serif H1 "AI workers that run your operations" (white, ~72px), subcopy (white), black "Book a demo" button. Below: "TRUSTED BY 150+ ENTERPRISE CUSTOMERS" + logo row.
2. **Logo marquee band** (`section-padding`, ~128px) — 9 carrier logos (logo-1..9.svg): Uber Freight, MODE, Ryder, DHL, Samsara, etc. Likely auto-scrolling marquee.
3. **Powering operational excellence** (`section_product-video`, ~790px) — 2-col. Left: eyebrow "BUILT FOR REAL OPERATIONS WORK", serif H2 (two-tone black/gray), paragraph, black "Book a demo" btn. Right: single image `Frame 1597881333.webp` (workflow mockup card: Supply chain coordinator + 4 numbered steps on blue→peach gradient).
4. **Use cases** (`section`, ~840px) — eyebrow "COMMON USE CASES", serif H2 two-tone "From coordination bottleneck to operational flow". Grid of 5 cream cards (`#F3F1E6`, radius 8px, pad 24px): 3 top row + 2 bottom row. Each: serif title, gray desc, hairline divider, dark stat line. Cards: Appointment Scheduling / Delivery Tracking / Maintenance Coordination / Exception Management / Vendor & Carrier Communication.
5. **Contact Intelligence** (`section_product-video`, ~477px) — 2-col. Left: single image `Shared insight...webp` (Christina Morgan profile + chat bubbles on gradient). Right: eyebrow "CONTACT INTELLIGENCE", serif H2 two-tone, paragraph.
6. **Why HappyRobot** (`section_layout241`, ~642px) — eyebrow "WHY HAPPYROBOT FOR OPERATIONS", serif H2 two-tone "Operations automation with HappyRobot", black "Book a demo" btn top-right area. 3-col text: Execution not just visibility / Behavioral change at scale / Coordination that compounds. Black "Learn more" btn bottom-left.
7. **How We Work** (`section_layout231`, ~805px) — cream bg `#F3F1E6`. Centered eyebrow "HOW WE WORK", serif H2 two-tone "From kickoff to live in weeks, not months". 3-col: big faded number (01/02/03), serif title (Build/Test/Deploy), gray desc.
8. **Proven Results** (`section_stats8`, ~707px) — centered eyebrow "PROVEN RESULTS", serif H2 "The numbers behind the work". Row of 5 big serif stats (75% / 100% / 27% / 63% / 1000x) + gray labels. Below: repeated carrier logo row.
9. **FAQ** (`section_faq7`, ~1313px) — centered serif H2 "Frequently asked questions". Static Q&A list (NOT accordion — all answers visible). 7 items: question (sans medium) + gray answer.
10. **CTA** (`section_cta`, ~484px) — full-bleed bridge photo bg (same `hero-bg@2x.webp`, darker). Centered serif white H2 "See what AI workers can do for your operations team" + black "Book a demo" btn.
11. **Footer** — bg `#FCFCFC`. Logo symbol left. 4 link cols: Product / Company / Terms & Policies / Social. 6 Vanta compliance badges (SOC2, GDPR, HIPAA, EU AI Act, NIST CSF, DORA). Tagline "Intelligence that runs your operations." + "© 2026 HappyRobot Inc."

## Interaction model
- Page: native scroll (no Lenis/Locomotive/scroll-snap detected).
- Nav: sticky, no significant scroll transform (stays white).
- Sections: static layout; likely subtle fade/slide-in on enter (Webflow IX2) — treat as optional.
- Logo rows: auto-scroll marquee.
- FAQ: static list, no toggle.
- Hidden `web-text-animation.mp4` (autoplay/loop/muted) exists — not visibly placed; treat as optional/skip.
