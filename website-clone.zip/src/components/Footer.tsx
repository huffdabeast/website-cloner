import { HappyRobotLogo } from "@/components/icons";

const LINK_COLUMNS: { heading: string; links: string[] }[] = [
  {
    heading: "Product",
    links: [
      "Platform Overview",
      "Agents",
      "Governance",
      "Context",
      "Interfaces",
      "Security & Reliability",
      "Developer Tools",
    ],
  },
  {
    heading: "Company",
    links: ["Customers", "Blog", "Hub", "Careers", "Media Kit"],
  },
  {
    heading: "Terms & Policies",
    links: [
      "Terms of service",
      "Privacy policy",
      "Cookie policy",
      "Consent Preferences",
    ],
  },
  {
    heading: "Social",
    links: ["LinkedIn", "X"],
  },
];

const COMPLIANCE_BADGES: { src: string; alt: string }[] = [
  { src: "/images/compliance/soc2.png", alt: "SOC 2" },
  { src: "/images/compliance/gdpr.png", alt: "GDPR" },
  { src: "/images/compliance/hipaa.png", alt: "HIPAA" },
  { src: "/images/compliance/eu-ai-act.png", alt: "EU AI Act" },
  { src: "/images/compliance/nist-csf.png", alt: "NIST CSF" },
  { src: "/images/compliance/dora.png", alt: "DORA" },
];

export function Footer() {
  return (
    <footer className="bg-background py-16">
      <div className="mx-auto max-w-[1280px] px-6">
        <div className="flex flex-col gap-12 md:flex-row md:gap-16">
          <HappyRobotLogo
            showWordmark={false}
            className="text-foreground h-8 w-12 shrink-0"
          />

          <div className="grid flex-1 grid-cols-2 gap-8 md:grid-cols-4">
            {LINK_COLUMNS.map((column) => (
              <div key={column.heading}>
                <h3 className="mb-4 text-sm text-muted-foreground">
                  {column.heading}
                </h3>
                <ul className="space-y-3">
                  {column.links.map((link) => (
                    <li key={link}>
                      <a
                        href="#"
                        className="text-sm text-foreground/90 transition hover:text-foreground"
                      >
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-12 flex flex-wrap justify-end gap-3">
          {COMPLIANCE_BADGES.map((badge) => (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              key={badge.src}
              src={badge.src}
              alt={badge.alt}
              className="h-12 w-12"
            />
          ))}
        </div>

        <div className="mt-8 flex justify-between text-sm text-muted-foreground">
          <span>Intelligence that runs your operations.</span>
          <span>© 2026 HappyRobot Inc.</span>
        </div>
      </div>
    </footer>
  );
}
