import { cn } from "@/lib/utils";

/**
 * HappyRobot logo: symbol mark (recolored from the white source SVG via CSS mask
 * so it inherits `currentColor`) + "HappyRobot" wordmark. Use text color to set fill,
 * e.g. `text-foreground` on light nav, `text-white` on photos.
 */
export function HappyRobotLogo({
  className,
  showWordmark = true,
}: {
  className?: string;
  showWordmark?: boolean;
}) {
  return (
    <span className={cn("inline-flex items-center gap-2", className)}>
      <svg
        viewBox="0 0 28 22"
        className="h-[22px] w-[28px]"
        fill="currentColor"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden
      >
        <path d="M13.694 12.6589C13.694 11.6079 13.1235 10.6396 12.2042 10.1303L9.02673 8.37006C8.10735 7.86073 7.53687 6.89251 7.53687 5.84147V0H0.28125V3.63794C0.28125 4.70778 0.872134 5.69014 1.81722 6.19153L4.90244 7.82829C5.84752 8.32967 6.43841 9.31203 6.43841 10.3819V21.3911H13.694V12.6589Z" />
        <path d="M27.2761 18.1703C27.2761 17.1091 26.6946 16.1333 25.7614 15.6281L22.489 13.8568C21.5558 13.3517 20.9744 12.3758 20.9744 11.3147V0H13.7188V9.00213C13.7188 10.0633 14.3002 11.0392 15.2334 11.5443L18.5058 13.3156C19.439 13.8207 20.0204 14.7966 20.0204 15.8577V21.3911H27.2761V18.1703Z" />
      </svg>
      {showWordmark && (
        <span className="text-[22px] font-semibold tracking-tight">
          HappyRobot
        </span>
      )}
    </span>
  );
}

type IconProps = React.SVGProps<SVGSVGElement>;

export function ArrowRightIcon(props: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M5 12h14M13 6l6 6-6 6" />
    </svg>
  );
}

export function ArrowDownIcon(props: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M12 5v14M6 13l6 6 6-6" />
    </svg>
  );
}

export function ArrowUpRightIcon(props: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M7 17 17 7M8 7h9v9" />
    </svg>
  );
}
