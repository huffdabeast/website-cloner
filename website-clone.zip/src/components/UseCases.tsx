import { cn } from "@/lib/utils";
import type { UseCase } from "@/types/content";

const cases: UseCase[] = [
  {
    title: "Appointment Scheduling",
    description:
      "AI workers manage full scheduling interactions — outreach, availability confirmation, booking, reschedules, and system updates. Across phone, email, message, or portal.",
    stat: "75% cost savings. What took a week now takes 15 minutes.",
  },
  {
    title: "Delivery Tracking",
    description:
      "Outbound tracking workflows that reach every carrier, confirm every status, and flag every exception. No load goes untracked because of team capacity.",
    stat: "80% → 100% carrier reach. 27% fewer late deliveries.",
  },
  {
    title: "Maintenance Coordination",
    description:
      "Full intake when equipment fails. AI workers gather details, classify issues, locate vendors, and book repairs in a single interaction. No hold time. No manual lookup.",
    stat: "63% reduction in call duration. Full visibility across every case.",
  },
  {
    title: "Exception Management",
    description:
      "When plans break — missed pickups, delayed shipments, equipment failures — AI workers coordinate the response in real time, keeping all parties informed.",
    stat: "Faster resolution. Fewer cascading failures.",
  },
  {
    title: "Vendor & Carrier Communication",
    description:
      "Systematic outreach for rate confirmations, capacity checks, and performance follow-ups at scale your team can't match manually.",
    stat: "Every partner contacted. Nothing falls through.",
  },
];

export function UseCases() {
  return (
    <section className="py-20 md:py-28">
      <div className="mx-auto max-w-[1280px] px-6">
        <p className="text-sm uppercase tracking-[0.12em] text-muted-foreground">
          Common Use Cases
        </p>
        <h2 className="mt-4 font-serif text-4xl leading-[1.05] tracking-tight text-foreground md:text-[40px]">
          From coordination{" "}
          <span className="text-muted-foreground">
            bottleneck to operational flow
          </span>
        </h2>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {cases.map((useCase) => (
            <div
              key={useCase.title}
              className={cn("flex flex-col rounded-lg bg-cream p-6")}
            >
              <h3 className="font-serif text-2xl text-foreground">
                {useCase.title}
              </h3>
              <p className="mt-3 flex-1 text-[15px] leading-relaxed text-muted-foreground">
                {useCase.description}
              </p>
              <div className="my-5 border-t border-border" />
              <p className="text-sm font-medium text-foreground">
                {useCase.stat}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
