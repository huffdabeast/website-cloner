import { cn } from "@/lib/utils";
import type { ValueProp } from "@/types/content";

const props: ValueProp[] = [
  {
    title: "Execution, not just visibility",
    description:
      "Most operations tools give you dashboards. HappyRobot gives you workers. The gap between knowing what needs to happen and having the capacity to do it — that's where operations fail. AI workers close the execution gap. Every appointment gets scheduled. Every load gets tracked. Every breakdown gets coordinated.",
  },
  {
    title: "Behavioral change at scale",
    description:
      "When carriers know every load receives consistent, exception-free follow-up, their behavior changes. When vendors know every repair gets tracked until resolution, response times improve. The systematic pressure of a system that never misses reshapes how your entire ecosystem operates.",
  },
  {
    title: "Coordination that compounds",
    description:
      "AI workers don't just execute — they learn. Carrier behavior patterns, vendor response times, scheduling preferences. The platform captures context from every interaction and applies it to the next. Operating procedures improve continuously at every touchpoint.",
  },
];

export function WhyHappyRobot() {
  return (
    <section className="py-20 md:py-28">
      <div className="mx-auto max-w-[1280px] px-6">
        <p className="text-sm uppercase tracking-[0.12em] text-muted-foreground">
          WHY HAPPYROBOT FOR OPERATIONS
        </p>
        <h2 className="mt-4 font-serif text-4xl leading-[1.05] tracking-tight text-foreground md:text-[40px]">
          Operations automation{" "}
          <span className="text-muted-foreground">with HappyRobot</span>
        </h2>
        <div className="mt-14 grid gap-10 md:grid-cols-3">
          {props.map((prop) => (
            <div key={prop.title}>
              <h3 className="font-serif text-2xl text-foreground">
                {prop.title}
              </h3>
              <p className="mt-3 text-[15px] leading-relaxed text-muted-foreground">
                {prop.description}
              </p>
            </div>
          ))}
        </div>
        <button
          type="button"
          className={cn(
            "mt-12 rounded-[4px] bg-foreground px-5 py-2.5 text-sm font-medium text-background transition hover:opacity-90",
          )}
        >
          Learn more
        </button>
      </div>
    </section>
  );
}
