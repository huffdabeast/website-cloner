import Image from "next/image";

export function CtaSection() {
  return (
    <section className="relative flex flex-col items-center justify-center overflow-hidden py-32 text-center">
      <Image
        src="/images/hero-bg.webp"
        alt=""
        fill
        className="object-cover object-center -z-10"
      />
      <div className="absolute inset-0 -z-10 bg-black/25" />
      <h2 className="mx-auto max-w-[760px] font-serif text-4xl leading-[1.05] text-white md:text-[56px]">
        See what AI workers can do for your operations team
      </h2>
      <button
        type="button"
        className="mt-8 rounded-[4px] bg-foreground px-5 py-2.5 text-sm font-medium text-background transition hover:opacity-90"
      >
        Book a demo
      </button>
    </section>
  );
}
