import Image from "next/image";
import { LogoMarquee } from "@/components/LogoMarquee";

export function Hero() {
  return (
    <section className="relative flex min-h-[88vh] flex-col overflow-hidden md:min-h-[745px]">
      <Image
        src="/images/hero-bg.webp"
        alt=""
        fill
        priority
        className="object-cover object-center -z-10"
      />
      <div className="mx-auto w-full max-w-[1280px] px-6 pt-28 text-center text-white">
        <p className="text-sm uppercase tracking-[0.15em] text-white/80">
          Operations
        </p>
        <h1 className="mx-auto mt-6 max-w-[900px] font-serif text-5xl leading-[1.05] tracking-tight text-white md:text-[72px]">
          AI workers that run your operations
        </h1>
        <p className="mx-auto mt-6 max-w-[620px] text-base text-white/90 md:text-lg">
          HappyRobot&apos;s AI workers automate scheduling, tracking, and
          maintenance coordination — at the volume your operations actually
          require. Your team focuses on strategic decisions, not putting out
          fires.
        </p>
        <button
          type="button"
          className="mx-auto mt-8 rounded-[4px] bg-foreground px-5 py-2.5 text-sm font-medium text-background transition hover:opacity-90"
        >
          Book a demo
        </button>
      </div>
      <div className="mx-auto mt-auto w-full max-w-[1280px] px-6 pb-10 text-center">
        <p className="text-xs uppercase tracking-[0.15em] text-white/70">
          Trusted by 150+ enterprise customers
        </p>
        <LogoMarquee tone="onDark" className="mt-6" />
      </div>
    </section>
  );
}
