import Image from "next/image";
import { cn } from "@/lib/utils";

export function ContactIntelligence() {
  return (
    <section className="py-20 md:py-28">
      <div className="mx-auto grid max-w-[1280px] grid-cols-1 items-center gap-10 px-6 md:grid-cols-2 md:gap-16">
        <Image
          src="/images/contact-intelligence.webp"
          alt="Customer profile and AI support chat threads"
          width={760}
          height={620}
          className="h-auto w-full rounded-xl"
        />
        <div>
          <p className="text-sm uppercase tracking-[0.12em] text-muted-foreground">
            Contact intelligence
          </p>
          <h2 className="mt-4 font-serif text-4xl leading-[1.05] tracking-tight text-foreground md:text-[40px]">
            <span className="block">Every interaction makes</span>
            <span className="block text-muted-foreground">
              the next one smarter
            </span>
          </h2>
          <p className="mt-6 text-muted-foreground">
            Every call, check-in, and status update adds to what your AI
            workforce knows about your carriers, vendors, and partners.
            HappyRobot captures behavior patterns, response preferences, and
            performance history — building persistent memory that makes every
            subsequent interaction more effective. When carriers know every load
            gets consistent, exception-free follow-up, their behavior changes.
          </p>
          <button
            type="button"
            className={cn(
              "mt-8 rounded-[4px] bg-foreground px-5 py-2.5 text-sm font-medium text-background transition hover:opacity-90"
            )}
          >
            Book a demo
          </button>
        </div>
      </div>
    </section>
  );
}
