import { cn } from "@/lib/utils";
import type { Stat } from "@/types/content";
import { LogoMarquee } from "@/components/LogoMarquee";

const stats: Stat[] = [
  { value: "75%", label: "cost savings on scheduling" },
  { value: "100%", label: "carrier reach" },
  { value: "27%", label: "fewer late deliveries" },
  { value: "63%", label: "reduction in call duration" },
  { value: "1000x", label: "faster scheduling" },
];

export function ProvenResults() {
  return (
    <section className="py-20 md:py-28">
      <div className="mx-auto max-w-[1280px] px-6 text-center">
        <p className="text-sm uppercase tracking-[0.12em] text-muted-foreground">
          PROVEN RESULTS
        </p>
        <h2 className="mt-3 font-serif text-4xl leading-tight tracking-tight text-foreground md:text-[48px]">
          The numbers behind the work
        </h2>
        <div className="mt-16 grid grid-cols-2 gap-8 md:grid-cols-5">
          {stats.map((stat) => (
            <div key={stat.label}>
              <div className="font-serif text-5xl text-foreground md:text-6xl">
                {stat.value}
              </div>
              <div className="mt-2 text-sm text-muted-foreground">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
        <LogoMarquee tone="onLight" className={cn("mt-20")} />
      </div>
    </section>
  );
}
