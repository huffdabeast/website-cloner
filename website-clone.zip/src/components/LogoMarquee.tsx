import { cn } from "@/lib/utils";

const LOGOS = Array.from({ length: 9 }, (_, i) => `/images/logos/logo-${i + 1}.svg`);

/**
 * Auto-scrolling carrier-logo marquee. `tone` recolors the monochrome SVGs:
 * - "onDark"  → white (for use over the bridge photo)
 * - "onLight" → muted gray (for the light Proven Results section)
 */
export function LogoMarquee({
  tone = "onLight",
  className,
}: {
  tone?: "onLight" | "onDark";
  className?: string;
}) {
  const filter =
    tone === "onDark"
      ? "[filter:brightness(0)_invert(1)] opacity-90"
      : "[filter:grayscale(1)_brightness(0)] opacity-50";

  // Duplicate the set so the -50% translate loops seamlessly.
  const items = [...LOGOS, ...LOGOS];

  return (
    <div className={cn("relative w-full overflow-hidden", className)}>
      <div className="flex w-max animate-marquee items-center gap-16">
        {items.map((src, i) => (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            key={i}
            src={src}
            alt=""
            aria-hidden
            className={cn("h-7 w-auto shrink-0", filter)}
          />
        ))}
      </div>
    </div>
  );
}
