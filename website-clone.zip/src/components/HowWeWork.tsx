import type { ProcessStep } from "@/types/content";

const steps: ProcessStep[] = [
  {
    number: "01",
    title: "Build",
    description:
      "We map your operations workflows, connect to your systems (TMS, WMS, dispatch, maintenance), and build AI workers tailored to how your team actually operates. No templates. Your processes, your logic.",
  },
  {
    number: "02",
    title: "Test",
    description:
      "Our proprietary evaluation engine runs adversarial scenarios in staging — testing edge cases, exception handling, and escalation paths before anything touches your operations.",
  },
  {
    number: "03",
    title: "Deploy",
    description:
      "Go live with confidence. Every production interaction is automatically audited and evaluated. Your AI workers improve continuously — learning patterns and optimizing coordination.",
  },
];

export function HowWeWork() {
  return (
    <section className="bg-cream py-20 md:py-28">
      <div className="mx-auto max-w-[1280px] px-6 text-center">
        <p className="text-sm uppercase tracking-[0.12em] text-muted-foreground">
          HOW WE WORK
        </p>
        <h2 className="mx-auto mt-4 font-serif text-4xl leading-[1.05] tracking-tight text-foreground md:text-[40px]">
          From kickoff to live{" "}
          <span className="text-muted-foreground">in weeks, not months</span>
        </h2>
        <div className="mt-16 grid gap-10 text-left md:grid-cols-3">
          {steps.map((step) => (
            <div key={step.number}>
              <p className="font-serif text-6xl leading-none text-muted-foreground/40">
                {step.number}
              </p>
              <h3 className="mt-4 font-serif text-3xl text-foreground">
                {step.title}
              </h3>
              <p className="mt-3 text-[15px] leading-relaxed text-muted-foreground">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
