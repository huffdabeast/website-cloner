import { HappyRobotLogo } from "@/components/icons";

const NAV_LINKS = ["Product", "Solutions", "Customers", "Blog", "Careers"];

export function Navbar() {
  return (
    <header className="sticky top-0 z-50 w-full bg-background border-b border-border/60">
      <div className="mx-auto flex h-16 max-w-[1280px] items-center justify-between px-6">
        <a href="#" aria-label="HappyRobot home">
          <HappyRobotLogo className="text-foreground" />
        </a>

        <nav className="hidden md:flex items-center gap-8">
          {NAV_LINKS.map((label) => (
            <a
              key={label}
              href="#"
              className="text-sm text-foreground/90 transition hover:text-foreground"
            >
              {label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <a
            href="#"
            className="rounded-[4px] bg-foreground px-4 py-2 text-sm font-medium text-background transition hover:opacity-90"
          >
            Book a demo
          </a>
          <button
            type="button"
            aria-label="Open menu"
            className="md:hidden text-foreground"
          >
            <svg
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth={1.5}
              strokeLinecap="round"
            >
              <path d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>
      </div>
    </header>
  );
}
