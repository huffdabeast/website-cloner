import type { FaqItem } from "@/types/content";

const items: FaqItem[] = [
  {
    question: "How does HappyRobot integrate with our TMS/WMS?",
    answer:
      "HappyRobot integrates natively with major transportation and warehouse management systems, dispatch platforms, and any system your team uses. AI workers operate within your existing stack.",
  },
  {
    question: "Can AI workers handle exceptions in real time?",
    answer:
      "Yes. When plans change, AI workers coordinate the response — contacting affected parties, updating systems, and escalating when human judgment is needed. Full context travels with every handoff.",
  },
  {
    question: "How is this different from our dispatch software?",
    answer:
      "Dispatch software manages data and workflows. HappyRobot AI workers do the coordination work — making the calls, sending the messages, and following up until tasks are complete. They work within your dispatch system, not around it.",
  },
  {
    question: "How quickly can we go live?",
    answer:
      "Enterprises are in production in weeks, not months. Our Forward Deployed Engineers work on-site to build, test, and deploy — getting your operations workflows live fast.",
  },
  {
    question: "What about data security?",
    answer:
      "HappyRobot is built for enterprise security requirements. Every interaction is audited, access is controlled, and the platform supports the compliance standards your organization requires — including SOC 2.",
  },
  {
    question: "Will this replace our ops team?",
    answer:
      "No. AI workers handle the coordination volume — scheduling, tracking, status updates. Your team focuses on exceptions, strategic decisions, and the work that requires human judgment.",
  },
  {
    question: "What channels do AI workers operate across?",
    answer:
      "Phone, email, SMS, web chat, WhatsApp, and API integrations with third-party portals. AI workers use whatever channel your partners and vendors prefer.",
  },
];

export function Faq() {
  return (
    <section className="py-20 md:py-28">
      <div className="mx-auto max-w-[900px] px-6">
        <h2 className="text-center font-serif text-4xl leading-tight tracking-tight text-foreground md:text-[56px]">
          Frequently asked questions
        </h2>
        <ul className="mt-14 space-y-10">
          {items.map((item) => (
            <li key={item.question}>
              <h3 className="text-lg font-medium text-foreground">
                {item.question}
              </h3>
              <p className="mt-2 max-w-[760px] text-[15px] leading-relaxed text-muted-foreground">
                {item.answer}
              </p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
