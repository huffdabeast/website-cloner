import Image from "next/image";
import { cn } from "@/lib/utils";

export function PoweringExcellence() {
  return (
    <section className="py-20 md:py-28">
      <div className="mx-auto grid max-w-[1280px] grid-cols-1 items-center gap-10 px-6 md:grid-cols-2 md:gap-16">
        <div>
          <p className="text-sm uppercase tracking-[0.12em] text-muted-foreground">
            Built for real operations work
          </p>
          <h2 className="mt-4 font-serif text-4xl leading-[1.05] tracking-tight text-foreground md:text-[40px]">
            Powering operational{" "}
            <span className="text-muted-foreground">excellence</span>
          </h2>
          <p className="mt-6 max-w-[460px] text-muted-foreground">
            HappyRobot AI workers handle the coordination-heavy work that keeps
            operations running — scheduling appointments, tracking deliveries,
            and managing maintenance across phone, email, and messaging. They
            integrate directly with your TMS, WMS, and dispatch systems to take
            action, not just send updates.
          </p>
          <button
            type="button"
            className={cn(
              "mt-8 rounded-[4px] bg-foreground px-5 py-2.5 text-sm font-medium text-background transition hover:opacity-90"
            )}
          >
            Book a demo
          </button>
        </div>
        <Image
          src="/images/powering-operations.webp"
          alt="Operations workflow with AI worker coordinating Slack, calls, documents and email"
          width={820}
          height={660}
          className="h-auto w-full rounded-xl"
        />
      </div>
    </section>
  );
}
