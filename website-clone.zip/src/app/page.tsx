import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { PoweringExcellence } from "@/components/PoweringExcellence";
import { UseCases } from "@/components/UseCases";
import { ContactIntelligence } from "@/components/ContactIntelligence";
import { WhyHappyRobot } from "@/components/WhyHappyRobot";
import { HowWeWork } from "@/components/HowWeWork";
import { ProvenResults } from "@/components/ProvenResults";
import { Faq } from "@/components/Faq";
import { CtaSection } from "@/components/CtaSection";
import { Footer } from "@/components/Footer";

export default function Home() {
  return (
    <>
      <Navbar />
      <main className="flex-1">
        <Hero />
        <PoweringExcellence />
        <UseCases />
        <ContactIntelligence />
        <WhyHappyRobot />
        <HowWeWork />
        <ProvenResults />
        <Faq />
        <CtaSection />
      </main>
      <Footer />
    </>
  );
}
