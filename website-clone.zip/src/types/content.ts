export interface NavLink {
  label: string;
  href: string;
}

export interface UseCase {
  title: string;
  description: string;
  stat: string;
}

export interface ValueProp {
  title: string;
  description: string;
}

export interface ProcessStep {
  number: string;
  title: string;
  description: string;
}

export interface Stat {
  value: string;
  label: string;
}

export interface FaqItem {
  question: string;
  answer: string;
}

export interface FooterColumn {
  heading: string;
  links: NavLink[];
}

export interface ComplianceBadge {
  name: string;
  src: string;
}
